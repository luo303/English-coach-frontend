export const AppPalette = {
  background: '#F6F8FB',
  surface: '#FFFFFF',
  surfaceSoft: '#EEF2F7',
  surfaceStrong: '#E5EAF2',
  foreground: '#111827',
  muted: '#667085',
  faint: '#98A2B3',
  border: '#DBE3EE',
  separator: '#E7EDF5',
  primary: '#2563EB',
  primarySoft: '#EAF1FF',
  success: '#16A34A',
  successSoft: '#EAF8F0',
  warning: '#F59E0B',
  warningSoft: '#FFF7E4',
  danger: '#DC2626',
  dangerSoft: '#FFF1F2',
  ink: '#111827',
  page: '#F6F8FB',
  card: '#FFFFFF',
  line: '#DBE3EE',
  blue: '#2563EB',
  blueSoft: '#EAF1FF',
  green: '#16A34A',
  greenSoft: '#EAF8F0',
  amberSoft: '#FFF7E4',
  red: '#DC2626',
};

export const AppRadius = {
  sm: 10,
  md: 14,
  lg: 18,
  xl: 22,
  round: 999,
};

export const AppSpacing = {
  screenX: 20,
  screenTop: 18,
  tabBar: 78,
};
