import { Alert, Button, Card, Chip } from 'heroui-native';
import { Text, View } from 'react-native';

import { ApiRuntimeConfig } from '@/config/runtime';
import { useAuthStore } from '@/state/authStore';

export function LoginScreen() {
  const error = useAuthStore((state) => state.error);
  const login = useAuthStore((state) => state.login);
  const status = useAuthStore((state) => state.status);
  const isLoading = status === 'loading';

  return (
    <View className="flex-1 justify-center bg-background px-6">
      <View className="mb-7">
        <Chip variant="soft" color="accent" className="mb-4 self-start">
          AI English Partner
        </Chip>
        <Text className="text-4xl font-black leading-[44px] text-foreground">登录后开始口语陪练</Text>
        <Text className="mt-3 text-base leading-6 text-muted">
          使用后端匿名登录创建练习身份，随后进入真实场景和实时语音链路。
        </Text>
      </View>

      <Card className="border border-border bg-surface p-5 shadow-surface">
        <Card.Body className="gap-3">
          <Text className="text-xl font-black text-foreground">匿名身份</Text>
          <Text className="text-base leading-6 text-muted">
            进入 App 前需要先获取 accessToken，所有练习会话和报告都会绑定到当前匿名用户。
          </Text>
          <View className="rounded-2xl bg-surface-secondary px-4 py-3">
            <Text className="text-xs font-bold uppercase text-muted">API Endpoint</Text>
            <Text className="mt-1 text-sm font-semibold text-foreground">{ApiRuntimeConfig.apiBaseUrl}</Text>
          </View>

          {error ? (
            <Alert status="danger">
              <Alert.Indicator />
              <Alert.Content>
                <Alert.Title>登录失败</Alert.Title>
                <Alert.Description>{error}</Alert.Description>
              </Alert.Content>
            </Alert>
          ) : null}

          <Button isDisabled={isLoading} onPress={() => void login()} size="lg" variant="primary">
            {isLoading ? '正在登录...' : '匿名登录'}
          </Button>
        </Card.Body>
      </Card>
    </View>
  );
}
