import { Alert, Card, Skeleton } from 'heroui-native';
import { ReactNode } from 'react';
import { Pressable, Text, View } from 'react-native';

type AppScreenHeaderProps = {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  actionLabel?: string;
  onActionPress?: () => void;
};

type AppMetricCardProps = {
  label: string;
  value: string;
  tone?: 'default' | 'accent' | 'success' | 'warning' | 'danger';
};

type AppStateProps = {
  title: string;
  description?: string;
};

export function AppScreenHeader({
  actionLabel,
  eyebrow,
  onActionPress,
  subtitle,
  title,
}: AppScreenHeaderProps) {
  return (
    <View className="mb-5 flex-row items-start justify-between gap-4">
      <View className="flex-1">
        {eyebrow ? <Text className="mb-1 text-sm font-semibold text-muted">{eyebrow}</Text> : null}
        <Text className="text-3xl font-black leading-9 text-foreground">{title}</Text>
        {subtitle ? <Text className="mt-2 text-base leading-6 text-muted">{subtitle}</Text> : null}
      </View>
      {actionLabel ? (
        <Pressable
          accessibilityRole="button"
          className="min-h-11 min-w-11 items-center justify-center rounded-2xl border border-border bg-surface px-3"
          onPress={onActionPress}
        >
          <Text className="text-sm font-black text-foreground">{actionLabel}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

export function AppSurface({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <Card className={`border border-border bg-surface p-4 shadow-surface ${className}`}>{children}</Card>;
}

export function AppMetricCard({ label, tone = 'default', value }: AppMetricCardProps) {
  const toneClass = {
    accent: 'text-accent',
    danger: 'text-danger',
    default: 'text-foreground',
    success: 'text-success',
    warning: 'text-warning',
  }[tone];

  return (
    <Card className="w-[48%] border border-border bg-surface p-4">
      <Text className="mb-2 text-sm font-semibold text-muted">{label}</Text>
      <Text className={`text-2xl font-black ${toneClass}`}>{value}</Text>
    </Card>
  );
}

export function AppEmptyState({ description, title }: AppStateProps) {
  return (
    <Alert status="default" className="mb-4">
      <Alert.Indicator />
      <Alert.Content>
        <Alert.Title>{title}</Alert.Title>
        {description ? <Alert.Description>{description}</Alert.Description> : null}
      </Alert.Content>
    </Alert>
  );
}

export function AppErrorState({ description, title }: AppStateProps) {
  return (
    <Alert status="danger" className="mb-4">
      <Alert.Indicator />
      <Alert.Content>
        <Alert.Title>{title}</Alert.Title>
        {description ? <Alert.Description>{description}</Alert.Description> : null}
      </Alert.Content>
    </Alert>
  );
}

export function AppSkeletonStack() {
  return (
    <View className="gap-3">
      <Skeleton className="h-24 w-full rounded-2xl" />
      <Skeleton className="h-24 w-full rounded-2xl" />
      <Skeleton className="h-24 w-full rounded-2xl" />
    </View>
  );
}
