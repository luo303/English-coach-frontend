import { Tabs } from 'heroui-native';
import { useState } from 'react';
import { Text, View } from 'react-native';

const selectors = [
  { label: '难度', value: 'B1-B2' },
  { label: '口音', value: '美式' },
  { label: '目标', value: '流利' },
];

export function DifficultySelector() {
  const [activeValue, setActiveValue] = useState(selectors[0].value);

  return (
    <View className="mb-4">
      <Tabs value={activeValue} onValueChange={setActiveValue} variant="primary">
        <Tabs.List>
          <Tabs.Indicator />
          {selectors.map((item) => (
            <Tabs.Trigger key={item.value} value={item.value}>
              <View className="items-center">
                <Text className="text-xs font-semibold text-muted">{item.label}</Text>
                <Tabs.Label className="text-sm font-black">{item.value}</Tabs.Label>
              </View>
            </Tabs.Trigger>
          ))}
        </Tabs.List>
      </Tabs>
    </View>
  );
}
