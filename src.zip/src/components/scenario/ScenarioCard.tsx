import { Card, Chip } from 'heroui-native';
import { Pressable, Text, View } from 'react-native';

import { Scenario } from '@/types/practice';

type ScenarioCardProps = {
  scenario: Scenario;
  selected: boolean;
  onPress: () => void;
};

export function ScenarioCard({ scenario, selected, onPress }: ScenarioCardProps) {
  return (
    <Pressable accessibilityRole="button" onPress={onPress}>
      <Card
        className={`border p-4 ${
          selected ? 'border-accent bg-accent-soft shadow-surface' : 'border-border bg-surface'
        }`}
      >
        <Card.Body className="gap-3">
          <View className="flex-row items-start justify-between gap-3">
            <Text className="flex-1 text-xl font-black leading-6 text-foreground">{scenario.title}</Text>
            <Chip color={selected ? 'accent' : 'default'} size="sm" variant={selected ? 'primary' : 'soft'}>
              {scenario.level}
            </Chip>
          </View>
          <Text className="text-[15px] leading-6 text-muted">{scenario.subtitle}</Text>
          <View className="flex-row flex-wrap gap-2">
            {scenario.focus.map((item) => (
              <Chip key={item} color="default" size="sm" variant="secondary">
                {item}
              </Chip>
            ))}
            <Chip color="success" size="sm" variant="soft">
              {scenario.minutes} 分钟
            </Chip>
          </View>
        </Card.Body>
      </Card>
    </Pressable>
  );
}
